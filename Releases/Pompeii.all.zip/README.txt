*******************
****  Pompeii  ****
**** Team WASD ****
*******************

This game was made as part of Global Game Jam 2015

This game is licensed under the Attribution-NonCommercial-ShareAlike 4.0 International license.
A copy of the license is available at
http://creativecommons.org/licenses/by-nc-sa/4.0/deed.en_US

The source and binaries are available from
http://globalgamejam.org/2015/games/pompeii

The source files require the Unity Client version 4.6.1 or later.

Credits:

Team WASD:
Charlie Strong
Kris Douglass
Lewis Fox
Nathan Saslavsky

Lava Sprite:
OpenGameArt.org user rh0
CC0 1.0

Rock Sprite:
OpenGameArt.org user phaelax
CC-BY-SA 3.0

Art: 
Anna X Sun
Steph Murphy

Testers:
David Chan
Chris GauthierDickey

Audio:
William Thrussell
